import pygame
import math
from pygame.locals import *
import random

pygame.init()
size = width, height = 700, 600
screen = pygame.display.set_mode(size)
pygame.display.set_caption("侠客道")
clock = pygame.time.Clock()
#导入角色图片
lan = pygame.image.load("Lan.png")
lan1 = pygame.image.load("Lan1.png")
xie = pygame.image.load("Xie.png")
xie1= pygame.image.load("Xie1.png")
Background = pygame.image.load("background.png")
#游戏结束界面
Gameover=pygame.image.load("Gameover.png")
Gameover1=pygame.image.load("Gameover1.png")
Gameover2=pygame.image.load("Gameover2.png")
#起始游戏界面
Single=pygame.image.load("Single.png")
Double=pygame.image.load("Double.png")
Single_rect=Single.get_rect()
Double_rect=Double.get_rect()
Single_rect.left=100
Single_rect.top=200
Double_rect.right=600
Double_rect.top=200
#双人
position1 = lan.get_rect()
position2 = xie.get_rect()
position1.top = 300
position1.left = 0
position2.top = 300
position2.right = 700
#单人
playerx=0
playery=400                                               #攻击者的初始位置
playerstep=0                                              #初始化攻击者的移动速度

#放背景音乐
pygame.mixer.music.load("bgm.ogg")
pygame.mixer.music.set_volume(0.2)
pygame.mixer.music.play()

# 导入音效
go_sound = pygame.mixer.Sound("go.wav")
go_sound.set_volume(0.3);
water_sound=pygame.mixer.Sound("水滴声.wav")
water_sound.set_volume(0.2);

#双人
# 计算雪球与对手的距离
def distance(sx, sy, px, py):
    a = px - sx
    b = (py+100) - sy
    return math.sqrt(a * a + b * b)


# 雪球类
class Snowball():
    def __init__(self, position):
        self.img = pygame.image.load('Snowball.png')
        self.x = position.left
        self.y = position.top + 25
        self.step = 6  # 速度

    def hit1(self):
        global is_over
        for s in snowball1:
            if (distance(self.x, self.y, position2.right, position2.top) < 50):
                snowball1.remove(self)
                water_sound.play()
                position2.top = 0
                position2.right = 0  # 复原
                is_over =1


    def hit2(self):
        global is_over
        for s in snowball2:
            if (distance(self.x, self.y, position1.right, position1.top) < 30):
                snowball2.remove(self)
                water_sound.play()
                position1.top = 0
                position1.right = 0  # 复原
                is_over =2


snowball1 = []  # 保存现有的雪球
snowball2 = []


def show_Snowball(position):
    if position.left == 0:
        for s in snowball1:
            s.x += s.step
            screen.blit(s.img, (s.x, s.y))
            s.hit1()
            if s.x > width:
                snowball1.remove(s)
    else:
        for s in snowball2:
            s.x -= s.step
            screen.blit(s.img, (s.x, s.y))
            s.hit2()
            if s.x < 0:
                snowball2.remove(s)


is_over = 0
def check_is_over():
    if is_over==1:
        screen.blit(Gameover1,(0,0))
    elif is_over==2:
        screen.blit(Gameover2,(0,0))
    elif is_over==3:
        screen.blit(Gameover,(0,0))
        
    
#单人
def show_player():#显示攻击者
    global playerx
    global playery
    screen.blit(lan,(playerx,playery))
    playery+=playerstep#游戏过程中，攻击者的位置变化
    if playery<0:
        playery=0
    if playery>444:
        playery=444
        
#设计与敌人有关的变量
                                                     
enemyx=600#初始化敌人的位置
enemyy=random.randint(200,500)
enemystep=random.randint(2,4)#初始化敌人的速度
def show_enemy():
    global enemyx
    global enemyy
    global enemystep
    screen.blit(xie,(enemyx,enemyy))
    enemyy+=enemystep
    if (enemyy>500 or enemyy<0):
        enemystep*=-1

class Bullet():
    def __init__(self):
        self.img = pygame.image.load('Snowball.png')
        self.x = playerx+38
        self.y = playery+10
        self.step = 6  #速度

    def hit3(self):
        global is_over
        for b in bullets:
            if (distance(self.x, self.y,enemyx,enemyy) < 30):
                is_over =3
bullets=[]


def show_bullet():
    b=Bullet()
    if playerx ==0 :
        for b in bullets:
            b.x += b.step
            screen.blit(b.img, (b.x, b.y))
            b.hit3()
            if b.x > enemyx:
                bullets.remove(b)

        
j=0
screen.blit(Background,(0,0))
screen.blit(Single,Single_rect)
screen.blit(Double,Double_rect)
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if j==0:
            if event.type ==pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if Double_rect.left < pos[0] <Double_rect.right and Double_rect.top < pos[1] < Double_rect.bottom:
                    j+=2
                if Single_rect.left < pos[0] <Single_rect.right and Single_rect.top < pos[1] < Single_rect.bottom:
                    j+=1
            
    if j==2:
        speed1 = [0, 0]
        speed2 = [0, 0]
        screen.blit(Background, (0, 0))
        screen.blit(lan, position1)
        screen.blit(xie, position2)
        if event.type == pygame.KEYDOWN:  # 用键盘控制小蓝移动
            if event.key == pygame.K_w:
                speed1 = [0, -1]
            if event.key == pygame.K_s:
                speed1 = [0, 1]
            if event.key == pygame.K_d:
                snowball1.append(Snowball(position1))
                screen.blit(lan1, position1)
                go_sound.play()
        if event.type == pygame.KEYDOWN:  # 用键盘控制小谢移动
            if event.key == pygame.K_UP:
                speed2 = [0, -1]
            if event.key == pygame.K_DOWN:
                speed2 = [0, 1]
            if event.key == pygame.K_LEFT:
                snowball2.append(Snowball(position2))
                screen.blit(xie1, position2)
                go_sound.play()
        position1 = position1.move(speed1)
        position2 = position2.move(speed2)
        # 防出界
        if position1.top < 0:
            position1.top = 0
        if position1.bottom > height:
            position1.bottom = height
        if position2.top < 0:
            position2.top = 0
        if position2.bottom > height:
            position2.bottom = height
        show_Snowball(position1)
        show_Snowball(position2)
        check_is_over()  # 显示游戏结束
        pygame.display.flip()
        clock.tick(500);
        #单人
    if j==1:   
        screen.blit(Background,(0,0))#背景
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:#若按下为向上键，则每次向上走5像素单位
                if event.key==pygame.K_w:
                    playerstep=-5
                elif event.key==pygame.K_s:#若按下为向下键，则每次往下走5像素单位
                    playerstep=5
                elif event.key==pygame.K_d:
                    bullets.append(Bullet())
                    go_sound.play()
            if event.type==pygame.KEYUP:#若键盘抬起，则停止走动
                    playerstep=0
        show_player()
        show_enemy()
        show_bullet()
        check_is_over()
        pygame.display.update()